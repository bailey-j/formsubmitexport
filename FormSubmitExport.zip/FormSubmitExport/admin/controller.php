<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

class SsdaFormController extends JControllerLegacy
{
	/**
	 * The default view for the display method.
	 *
	 * @var string
	 * @since 12.2
	 */
	protected $default_view = 'ssdaforms';
}