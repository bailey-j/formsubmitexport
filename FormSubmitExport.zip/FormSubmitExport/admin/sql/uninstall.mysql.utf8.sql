DROP TABLE IF EXISTS `#__ssdaform_form`;

DROP TABLE IF EXISTS `#__ssdaform_submission`;